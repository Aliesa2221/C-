package Taskes;

import baseClasses.Node;

import java.util.*;

/*
    Finding the easiest routes
 */
public class TaskFour<T> {

    Collection<T> dijkstraAlgorithm(WeightedGraph<T> graph, T source, T dest) {
        if (!graph.isReachable(source, dest)) return null;
        graph.InitializeDistancesFromSource(source);
        Map<T, Node<T>> nodesMap = graph.getNodesMap();
        Node<T> destinationNode = nodesMap.get(dest);
        List<T> path = new LinkedList<>();
        Node<T> temp = destinationNode;
        while (temp != null) {
            path.add(temp.getData());
            temp = temp.getParent();
        }
        Collections.reverse(path);
        return path;
    }
}
