package Taskes;

import baseClasses.IGraph;

/**
 * Interface that declares attributes of WeightedGraph
 * implements IGraph<T> interface
 * @param <T>
 */
public interface WeightedGraph<T> extends IGraph<T> {
    /**
     * return the graph's weight between two nodes
     * @param nodeOne node 1
     * @param nodeTwo node 2
     * @return if the node have an edges the function will return the weight.
     * else the function will return null.
     */
    Integer getWeight(T nodeOne, T nodeTwo);

    /**
     * In the nodeMap, set the distance and parents of the nodes.
     * @param sourceIndex the index of the source
     */
    void InitializeDistancesFromSource(T sourceIndex);
}
