package Taskes;

import baseClasses.Index;
import baseClasses.Node;

import java.util.*;
/*
    It uses the adapter pattern
    Make Weighted Matrix adapts as Weighted Graph for the functionality of graph
 */
public class WeightedMatrixAsGraph implements WeightedGraph<Index> {

    private WeightedMatrix innerMatrix;
    private Map<Index, Node<Index>> nodesMap;
    private Index source;

    public WeightedMatrixAsGraph(WeightedMatrix matrix) {
        // In case they send me a non-empty array
        if (matrix != null) this.innerMatrix = matrix;

        // In case it is not empty then a random matrix is made
        else innerMatrix = new WeightedMatrix();
        // Put the root at the beginning of a matrix
//        source = new Index(0, 0);
        setSource();
        setNodesMap();
    }


    public WeightedMatrix getInnerMatrix() {
        return innerMatrix;
    }

    public Index getSource() {
        return source;
    }


    private void setSource() {
        int[][] arr = this.innerMatrix.primitiveMatrix;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] > 0) {
                    source = new Index(i, j);
                    return;
                }
            }
        }
    }

    @Override
    public boolean nextNodeInTheGraph() {
        int[][] arr = this.innerMatrix.primitiveMatrix;
        for (int j = source.getColumn() + 1; j < arr[source.getRow()].length; j++) {
            if (arr[source.getRow()][j] > 1) {
                source = new Index(source.getRow(), j);
                return true;
            }
        }
        for (int i = source.getRow() + 1; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] > 1) {
                    source = new Index(i, j);
                    return true;
                }

            }
        }
        return false;
    }

    @Override
    public Node<Index> getRoot() {
        return new Node<>(source);
    }

    @Override
    public boolean backToRoot() {
        setSource();
        return true;
    }

    @Override
    public Integer getWeight(Index i, Index j) {
        Node<Index> iIndex = new Node<>(i);
        Node<Index> jIndex = new Node<>(j);
        if (getReachableNodes(iIndex).contains(jIndex)) {
            return innerMatrix.getValue(i) + innerMatrix.getValue(j);
        }
        return null;
    }
    @Override
    public Collection<Node<Index>> getReachableNodes(Node<Index> aNode) {
        // Only if the vertex passed to me and the value of its index is one will I do the rest of the function
        if (innerMatrix.getValue(aNode.getData()) > 0) {
            // Create a list that contains the list of neighbors in the node
            List<Node<Index>> reachableNodes = new ArrayList<>();
            // For any neighbor of the same node of the node they sent me
            for (Index index : innerMatrix.getNeighbors(aNode.getData())) {
                // If the value in the same index is equal to one
                if (innerMatrix.getValue(index) > 0) {
                    Node<Index> newNode = new Node<>(index);
                    // We will add it as a node to the list of neighbors
                    reachableNodes.add(newNode);
                }
            }
            return reachableNodes;
        }
        // If it's not equal to one then I'll return an empty list - null
        return null;
    }



    @Override
    public void InitializeDistancesFromSource(Index source) {
        // To call the function several times
        for (Node<Index> n : this.nodesMap.values()) n.setDist(Integer.MAX_VALUE);

        Map<Index, Boolean> isVisited = Collections.synchronizedMap(new HashMap<>());
        for (Map.Entry<Index, Node<Index>> entry : this.nodesMap.entrySet())
            isVisited.put(entry.getKey(), false);

        Node<Index> sourceNode = this.getNode(source);
        Stack<Node<Index>> workingStack = new Stack<>();


        sourceNode.setDist(0);
        workingStack.push(sourceNode);
        while (!workingStack.isEmpty()) {
            Node<Index> remove = workingStack.pop();
            isVisited.put(remove.getData(), true);
            Collection<Node<Index>> neighbours = this.getReachableNodes(remove);

            for (Node<Index> neighbor : neighbours) {
                int tempDist = nodesMap.get(neighbor.getData()).getDist();
                int distanceBetweenRemoveTempNodeFromStart = this.getWeight(remove.getData(), neighbor.getData()) + remove.getDist();
                if (tempDist < distanceBetweenRemoveTempNodeFromStart) {
                    neighbor.setDist(tempDist);
                    neighbor.setParent(nodesMap.get(neighbor.getData()).getParent());
                } else {
                    neighbor.setDist(distanceBetweenRemoveTempNodeFromStart);
                    neighbor.setParent(remove);
                }
                nodesMap.put(neighbor.getData(), neighbor);
                if (!isVisited.get(neighbor.getData())) {
                    isVisited.put(neighbor.getData(), true);
                    workingStack.push(neighbor);
                }
            }
        }
    }

    // set Nodes into map
    private void setNodesMap() {
        this.nodesMap = Collections.synchronizedMap(new HashMap<>());
        for (int i = 0; i < innerMatrix.primitiveMatrix.length; i++) {
            for (int j = 0; j < innerMatrix.primitiveMatrix[i].length; j++) {
                Index temp = new Index(i, j);
                if (innerMatrix.getValue(temp) > 0)
                    nodesMap.put(temp, new Node<>(temp));
            }
        }
    }

    @Override
    public Map<Index, Node<Index>> getNodesMap() {
        return this.nodesMap;
    }
    // gets Node
    @Override
    public Node<Index> getNode(Index data) {
        return this.nodesMap.get(data);
    }

    @Override
    public boolean isReachable(Index n1, Index n2) {
        Map<Index, Boolean> isVisited = Collections.synchronizedMap(new HashMap<>());
        for (Map.Entry<Index, Node<Index>> entry : this.nodesMap.entrySet())
            isVisited.put(entry.getKey(), false);

        Queue<Index> workingQ = new LinkedList<>();
        workingQ.add(n1);
        while (!workingQ.isEmpty()) {
            Index removed = workingQ.remove();
            isVisited.put(removed, true);
            Collection<Node<Index>> neighbors = this.getReachableNodes(new Node<>(removed));
            for (Node<Index> neighbor : neighbors) {
                Index neighborIndex = neighbor.getData();
                if (neighborIndex.equals(n2))
                    return true;
                if (!isVisited.get(neighborIndex)) {
                    isVisited.put(neighborIndex, true);
                    workingQ.add(neighborIndex);
                }
            }
        }
        return false;
    }

}





