package Taskes;

import baseClasses.IGraph;
import baseClasses.Node;

import java.util.*;

public class TaskOne<T> {

    // Which vertices I visit
    private Stack<Node<T>> workingStack;
    // A set of those I have already visited in the current round
    private Set<Node<T>> finished;
    // A set of vertices I visited
    private Set<Node<T>> visitedVertices;

    public TaskOne() {
        workingStack = new Stack<>();
        finished = new LinkedHashSet<>();
        visitedVertices = new LinkedHashSet<>();

    }

    public LinkedList<LinkedList<T>> allConnectedComponents(IGraph<T> graph) {
        // the return HashSet
        LinkedList<LinkedList<T>> components = new LinkedList<>();

        do {
            // If the current root has been visited, we will search the visitedVertices for a new root.
            if (visitedVertices.contains(graph.getRoot())) {
                continue;
            }

            //Depth First Search (DFS)
            // add the graph's root to the stack
            workingStack.push(graph.getRoot());
            // We will not investigate these components if the stack is empty.
            while (!workingStack.isEmpty()) {
                Node<T> removed = workingStack.pop();
                //enter to the finished set
                finished.add(removed);
                // get the reachable nodes (neighbors) of this node
                Collection<Node<T>> reachableNodes = graph.getReachableNodes(removed);
                // for each loop, we want to explore the neighbor if we haven't done so already.
                for (Node<T> reachableNode : reachableNodes) {
                    if (!finished.contains(reachableNode) && !workingStack.contains(reachableNode))
                        // push the reachableNode to the stack if stack do not have it already.
                        workingStack.push(reachableNode);
                }
            }
            // when we're done searching from the root we will add the components to the visitedVertices list
            // we just want the data and not the all nodes, so we put the finished set in new HashSet
            List<T> dataSet = new LinkedList<>();
            for (Node<T> node : finished) {
                dataSet.add(node.getData());
                visitedVertices.add(node);
            }
            // and add the dataSet that we get to the components HashSet
            components.add(new LinkedList<>(dataSet));

            // and clear both dataSet and alreadyVisited sets
            dataSet.clear();
            finished.clear();
          // find a new root - if the graph is ended it will return false
        } while (graph.nextNodeInTheGraph());


        graph.backToRoot();
        visitedVertices.clear();
        //we return the components
        return components;
    }
}
