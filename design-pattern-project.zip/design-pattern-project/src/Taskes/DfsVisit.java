package Taskes;

import baseClasses.Index;
import baseClasses.Node;

import java.util.Collection;
import java.util.Map;

/*
    Demo class where the main() function of the task 4 lies.
 */
public class DfsVisit {

    public static void main(String[] args) {
//        int[][] mat = {
//             //  0  1  2
//                {1, 0, 0}, // 0
//                {1, 1, 0}, // 1
//                {1, 1, 1}, // 2
//                {1, 1, 1}, // 3
//                {1, 1, 1}, // 4
//        };
        int[][] mat = {
                {100, 100, 100},
                {500, 100, 300},
        };

        WeightedMatrixAsGraph weightedMatrix = new WeightedMatrixAsGraph(new WeightedMatrix(mat));
        weightedMatrix.InitializeDistancesFromSource(new Index(1, 0));
        System.out.println(weightedMatrix.getNodesMap());
        System.out.println(weightedMatrix.isReachable(new Index(0,0), new Index(0,1)));
        Map<Index, Node<Index>> nodesMap = weightedMatrix.getNodesMap();
        TaskFour<Index> taskFour = new TaskFour<>();
//        for(Map.Entry e : nodesMap.entrySet())
//            System.out.println(e.getValue());
//        Collection<Index> al2 = q4.func(weightedMatrix, new Index(1, 0), new Index(1, 2));
        for (int i = 0; i < 1; i++) {
//            Collection<Index> al = q4.func(weightedMatrix, new Index(1, 0), new Index(1, 2));
            Collection<Index> al2 = taskFour.dijkstraAlgorithm(weightedMatrix, new Index(1, 0), new Index(1, 2));
            System.out.println(al2);
        }
    }
}
