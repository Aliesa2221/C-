package Taskes;

import baseClasses.IGraph;
import baseClasses.Index;
import baseClasses.Node;

import java.util.*;

public class TaskTwo {


    public LinkedList<Queue<Index>> shortestPath(IGraph<Index> graph, Index source, Index destination) {

        // List of all routes from source to destination
        LinkedList<Queue<Index>> phatFromSourceToDestination = new LinkedList<>();

        // We put the source and destination in a node
        Node<Index> sourceNode = new Node<>(source);
        Node<Index> destinationNode = new Node<>(destination);

        // A variable that contains the route by each index
        LinkedHashMap<Index, Queue<Index>> map = new LinkedHashMap<>();

        Queue<Node<Index>> workingQ = new LinkedList<>();
        HashSet<Node<Index>> visited = new HashSet<>();

            // Queue for destination junction
        Queue<Index> path = new LinkedList<>();
        map.put(source, path);

        workingQ.add(sourceNode);

        while (!workingQ.isEmpty()) {
            // Takes out what will be at the top of the stack
            Node<Index> removed = workingQ.remove();
            // Indicates I visited the intersection
            visited.add(removed);
            // Souls in the queue of the remove itself
            map.get(removed.getData()).add(removed.getData());

            Collection<Node<Index>> neighbors = graph.getReachableNodes(removed);
            for (Node<Index> neighbor : neighbors) {
                // Checks if the neighbor is the target
                if (neighbor.equals(destinationNode)) {
                    // Adds it to the list of routes
                    map.get(removed.getData()).add(neighbor.getData());
                    // Adds it to the list of routes
                    phatFromSourceToDestination.add(map.get(removed.getData()));
                }
                // If I had not visited him
                if (!visited.contains(neighbor) && !workingQ.contains(neighbor)) {
                    // Adds it to the record
                    workingQ.add(neighbor);
                    // To add the route to the map
                    Queue<Index> q = new LinkedList<>(map.get(removed.getData()));
                    map.put(neighbor.getData(), q);
                }
            }

        }

        // You have to filter out the shortest of all the routes
        // Need to find the size of the shortest route
        int minLength = phatFromSourceToDestination.getFirst().size();
        // To find his double
        for (Queue<Index> q : phatFromSourceToDestination)
            minLength = Math.min(minLength, q.size());

        // We will create a list of the queues we will return
        LinkedList<Queue<Index>> finalPath = new LinkedList<>();
        // We will only list queues whose size is equal to the minimum size
        for (Queue<Index> q : phatFromSourceToDestination)
            if (q.size() == minLength)
                finalPath.add(q);

        return finalPath;
    }
}
