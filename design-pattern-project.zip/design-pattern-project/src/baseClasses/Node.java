package baseClasses;


import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.util.Objects;

/**
 * Model Class for Node
 * @param <T>
 * implements Serializable, Comparable interfaces
 */
public class Node<T> implements Serializable, Comparable<Node<T>> {

    private static final Long serialVersionUID = 1L;

    private T data;
    private Node<T> parent;
    private int dist;

    public Node(T data) {
        this.data = data;
        this.parent = null;
        dist = Integer.MAX_VALUE;
    }

    public Node() {
        this(null);
    }

    public T getData() {
        return data;
    }

    public void setData(@NotNull T data) {
        this.data = data;
    }

    public Node<T> getParent() {
        return parent;
    }

    public void setParent(Node<T> parent) {
        this.parent = parent;
    }


    @Override
    public int compareTo(@NotNull Node<T> o) {
        return (this.getDist() < o.getDist()) ? -1 : ((this.getDist() == o.getDist()) ? 0 : 1);
    }

    // override equals method to compare two nodes
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Node)) return false;
        Node<?> state1 = (Node<?>) o;
        return Objects.equals(data, state1.data);
    }


    // override hashCode() method to get hash
    @Override
    public int hashCode() {
        return data != null ? data.hashCode() : 0;
    }


    public int getDist() {
        return dist;
    }

    public void setDist(int dist) {
        this.dist = dist;
    }

    // it will be used to display parent.
    String displayParent(){
        if (parent == null)
            return null;
        return parent.getData() + "";
    }

    // Override the default toString() method to print my custom attributes of the object Node.
    @Override
    public String toString() {
        return "Node{" +
                "data=" + data +
                ", parent=" + displayParent() +
                ", dist=" + dist +
                '}';
    }
}

