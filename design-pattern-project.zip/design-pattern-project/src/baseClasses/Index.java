package baseClasses;

import java.util.Objects;
/*
 * Model class for Index to create Index Object used further in our project
 */
public class Index{

    public int row;
    public int column;

    public Index(final int row, final int column) {
        this.row=row;
        this.column=column;
    }

    // Override the hashCode() method to returns the hash of row, column
    @Override
    public int hashCode() {
        return Objects.hash(row, column);
    }

    // Overrides the equals() method to compare the Index
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Index index = (Index) o;
        return row == index.row &&
                column == index.column;
    }


    // Overrides the toString() method according to our needs
    @Override
    public String toString() {
        return "("+row +
                "," + column +
                ')';
    }

    /*
    below are the setter and getter methods to set and get value from the fields of Index class
     */
    public int getRow() {
        return row;
    }

    public int getColumn() {
        return column;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public void setColumn(int column) {
        this.column = column;
    }
}
