package baseClasses;


import java.util.*;

/**
 * The Adapter pattern, also known as Wrapper/Decorator, is used in this class.
 * The class adapts a Matrix type to the IGraph interface's features.
 */

public class MatrixAsGraph implements IGraph<Index> {
    private Matrix innerMatrix;
    private Index source;
    private Map<Index, Node<Index>> nodesMap;


    public MatrixAsGraph(Matrix matrix) {
        // Coincidentally and passed me a non-empty matrix
        if (matrix != null) this.innerMatrix = matrix;
        // In case it is not empty then a random matrix is made
        else innerMatrix = new Matrix();
          // Put the root at the beginning of the matrix
//        source = new Index(0, 0);
        setSource();
        setNodesMap();
    }

    public Matrix getInnerMatrix() {
        return innerMatrix;
    }

    public Index getSource() {
        return source;
    }

    private void setSource() {
        int[][] arr = this.innerMatrix.primitiveMatrix;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] == 1) {
                    source = new Index(i, j);
                    return;
                }
            }
        }
    }

    // Method for locating the next node in a graph
    @Override
    public boolean nextNodeInTheGraph() {
        int[][] arr = this.innerMatrix.primitiveMatrix;
        // for loop iterates over column of the source
        for (int j = source.getColumn() + 1; j < arr[source.getRow()].length; j++) {
            if (arr[source.getRow()][j] == 1) {
                source = new Index(source.getRow(), j);
                return true;
            }
        }
        for (int i = source.getRow() + 1; i < arr.length; i++) {
            // for loop iterates over row of source
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] == 1) {
                    source = new Index(i, j);
                    return true;
                }

            }
        }
        return false;
    }

    // return to back to root
    @Override
    public boolean backToRoot() {
        setSource();
        return true;
    }

    @Override
    public Node<Index> getNode(Index index) {
        return innerMatrix.getValue(index) == 1 ? new Node<>(index) : null;
    }

    // get Root
    @Override
    public Node<Index> getRoot() {
        return new Node<>(source);
    }

    @Override
    public Collection<Node<Index>> getReachableNodes(Node<Index> aNode) {
        // Only if the vertex has passed to me and its index value is one, will I do the rest of the function
        if (innerMatrix.getValue(aNode.getData()) == 1) {
                // A list that will contain my list of neighbors should be in a node
                List<Node<Index>> reachableNodes = new ArrayList<>(); // רשימה שתכיל לי את הרשימה של השכנים ב node
            for (Index index : innerMatrix.getNeighbors(aNode.getData())) {
                if (innerMatrix.getValue(index) == 1) {
                    // For each node of the node since an equal of the same index is "equal to 1", it should be kept in newNode
                    Node<Index> newNode = new Node<>(index);
                    // We will add it to the list of neighbors "reachableNodes"
                    reachableNodes.add(newNode);
                }
            }

            //  Remember the same list
            return reachableNodes;
        }
        // If this is not one then I will return an empty list - null
        return null;
    }

    @Override
    public Map<Index, Node<Index>> getNodesMap() {
        return this.nodesMap;
    }


    // Set nodes into Map
    public void setNodesMap() {
        this.nodesMap = Collections.synchronizedMap(new HashMap<>());
        for (int i = 0; i < innerMatrix.primitiveMatrix.length; i++) {
            for (int j = 0; j < innerMatrix.primitiveMatrix[i].length; j++) {
                Index temp = new Index(i, j);
                if (innerMatrix.getValue(temp) == 1)
                    nodesMap.put(temp, new Node<>(temp));
            }
        }
    }

    // Check for the neighbour nodes
    @Override
    public boolean isReachable(Index indexOne, Index indexTwo) {
        Map<Index, Boolean> isVisited = Collections.synchronizedMap(new HashMap<>());
        for (Map.Entry<Index, Node<Index>> entry : this.nodesMap.entrySet())
            isVisited.put(entry.getKey(), false);

        Queue<Index> workingQ = new LinkedList<>();
        workingQ.add(indexOne);
        while (!workingQ.isEmpty()) {
            Index removed = workingQ.remove();
            isVisited.put(removed, true);
            Collection<Node<Index>> neighbors = this.getReachableNodes(new Node<>(removed));
            for (Node<Index> neighbor : neighbors) {
                Index neighborIndex = neighbor.getData();
                if (neighborIndex.equals(indexTwo))
                    return true;
                if (!isVisited.get(neighborIndex)) {
                    isVisited.put(neighborIndex, true);
                    workingQ.add(neighborIndex);
                }
            }
        }
        return false;
    }

}
