package baseClasses;



import java.util.Collection;
import java.util.Map;

/**
 * The common functionality required of a Graph is written in this interface
 */
public interface IGraph<T> {

    /**
     * First it gets the root node of the graph
     * @return the root node of the graph
     */
    Node<T> getRoot();
    /**
     * if we want to visit back to the root node
     * @return true If the operation was successful
     */
    boolean backToRoot();

    /**
     * if we want to visit the next node in the graph
     * @return true If the operation was successful
     */
    boolean nextNodeInTheGraph();

    /**
     * get an index and return its Node on the graph
     * @param index the index of the node we want to get
     * @return the node if it exists otherwise null
     */
    Node<T> getNode(T index);

    /**
     * get all the reachable nodes from a node
     * @param node the node we are pass as a param
     * @return a Collection of the reachable nodes from the node
     */
    Collection<Node<T>>  getReachableNodes(Node<T> node);

    /**
     * get map of all nodes on the graph with generic value as key.
     * @return map of all nodes on the graph with generic value as key
     */
    <K> Map<K, Node<T>> getNodesMap();

    /**
     * To determine if two nodes are linked
     * @param indexOne is the initial node's index.
     * @param indexTwo the second node's index
     * @return true If they're linked, else false.
     */
    boolean isReachable(T indexOne, T indexTwo);
}
