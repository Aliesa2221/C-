import baseClasses.Index;
import baseClasses.Matrix;
import baseClasses.MatrixAsGraph;
import Taskes.TaskTwo;

import java.util.LinkedList;
import java.util.Queue;

public class DfsVisit {
    public static void main(String[] args) {
        int[][] mat = {
                //  0  1  2
                {1, 0, 0}, // 0
                {1, 1, 0}, // 1
                {1, 1, 1}, // 2
                {1, 1, 1}, // 3
                {1, 1, 1}, // 4
        };


//        int[][] mat = {
//             //  0 1 2 3 4
//           /*0*/{0,1,1,0,0},
//           /*1*/{0,0,0,0,1},
//           /*2*/{0,0,0,0,1},
//        };

        MatrixAsGraph matrixAsGraph = new MatrixAsGraph(new Matrix(mat));

        TaskTwo shortsAll = new TaskTwo();
        LinkedList<Queue<Index>> shortes = shortsAll.shortestPath(matrixAsGraph, new Index(0,0), new Index(2,0));
        System.out.println(shortes);
    }

}
